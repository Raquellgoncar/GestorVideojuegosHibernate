package Vista;

import Modelo.DAO.Imp.PlataformaDAO_imp;
import Modelo.DAO.Imp.VideojuegoDAO_imp;
import Modelo.DAO.PlataformaDAO;
import Modelo.DAO.VideojuegoDAO;
import Modelo.Plataforma;
import Modelo.Usuario;
import Modelo.Videojuego;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Diálogo para la actualización de un videojuego existente.
 * <p>
 * Permite modificar los datos de un videojuego (título, plataforma,
 * año y valoración) y gestionar si está marcado como favorito.
 * Las plataformas se cargan dinámicamente desde la BD.
 * El favorito se gestiona directamente como campo booleano en
 * la entidad {@code Videojuego}, sin tabla separada.
 * </p>
 *
 * @author Raquel
 * @version 2.1
 */
public class ActualizarVideojuegoDialog extends JDialog {

    /** Campos de texto del formulario */
    private JTextField txtTitulo, txtAnio;

    /**
     * Desplegable de plataformas cargado desde la BD.
     * El {@code toString()} de {@code Plataforma} devuelve el nombre visible.
     */
    private JComboBox<Plataforma> cmbPlataforma;

    /** Desplegable de valoración (1-10) */
    private JComboBox<Integer> cmbValoracion;

    /** Área de texto para las anotaciones */
    private JTextArea txtAnotaciones;

    /** Botón para marcar o desmarcar el videojuego como favorito */
    private JToggleButton btnFavorito;

    /** Botones de acción del diálogo */
    private JButton btnAceptar, btnCancelar;

    /** Usuario autenticado */
    private Usuario usuario;

    /** Videojuego que se va a actualizar */
    private Videojuego videojuego;

    /** DAO para la gestión de videojuegos */
    private VideojuegoDAO videojuegoDAO = new VideojuegoDAO_imp();

    /** Recursos de internacionalización */
    private ResourceBundle texts;

    /**
     * Constructor del diálogo de actualización de videojuegos.
     *
     * @param parent     ventana padre
     * @param usuario    usuario autenticado
     * @param videojuego videojuego a modificar
     */
    public ActualizarVideojuegoDialog(
            JFrame parent,
            Usuario usuario,
            Videojuego videojuego
    ) {
        super(parent, true);
        this.usuario = usuario;
        this.videojuego = videojuego;

        texts = ResourceBundle.getBundle("i18n.messages");

        setTitle(texts.getString("update.dialog.window.title"));
        setSize(560, 580);
        setLocationRelativeTo(parent);
        setResizable(false);

        initComponents();
        cargarDatos();
    }

    /**
     * Inicializa y organiza los componentes gráficos del diálogo.
     */
    private void initComponents() {

        setLayout(new BorderLayout());

        JPanel root = new JPanel(new GridBagLayout());
        root.setBorder(BorderFactory.createEmptyBorder(30, 30, 0, 30));
        add(root, BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(14, 10, 14, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        /* ===== TÍTULO ===== */
        JLabel lblTitulo = new JLabel(
                texts.getString("update.dialog.title"),
                SwingConstants.CENTER
        );
        lblTitulo.setFont(new Font("Showcard Gothic", Font.PLAIN, 34));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        root.add(lblTitulo, gbc);

        /* ===== NOMBRE DEL JUEGO ===== */
        JLabel lblNombre = new JLabel(videojuego.getTitulo(), SwingConstants.CENTER);
        lblNombre.setFont(new Font("Arial Black", Font.PLAIN, 22));
        lblNombre.setForeground(Color.DARK_GRAY);
        lblNombre.setBorder(BorderFactory.createEmptyBorder(6, 0, 10, 0));

        gbc.gridy++;
        root.add(lblNombre, gbc);

        gbc.gridwidth = 1;
        Font fuenteLabel = new Font("Arial", Font.BOLD, 15);

        /* ===== CAMPO TÍTULO ===== */
        gbc.gridy++;
        JLabel lblT = new JLabel(texts.getString("update.field.title") + ":");
        lblT.setFont(fuenteLabel);
        root.add(lblT, gbc);

        txtTitulo = crearCampoTexto();
        gbc.gridx = 1;
        root.add(txtTitulo, gbc);

        /* ===== CAMPO PLATAFORMA ===== */
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblP = new JLabel(texts.getString("update.field.platform") + ":");
        lblP.setFont(fuenteLabel);
        root.add(lblP, gbc);

        cmbPlataforma = new JComboBox<>();
        cargarPlataformas();
        cmbPlataforma.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        cmbPlataforma.setPreferredSize(new Dimension(260, 34));
        gbc.gridx = 1;
        root.add(cmbPlataforma, gbc);

        /* ===== CAMPO AÑO ===== */
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblA = new JLabel(texts.getString("update.field.year") + ":");
        lblA.setFont(fuenteLabel);
        root.add(lblA, gbc);

        txtAnio = crearCampoTexto();
        gbc.gridx = 1;
        root.add(txtAnio, gbc);

        /* ===== CAMPO VALORACIÓN ===== */
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblV = new JLabel(texts.getString("update.field.rating") + ":");
        lblV.setFont(fuenteLabel);
        root.add(lblV, gbc);

        cmbValoracion = new JComboBox<>();
        for (int i = 1; i <= 10; i++) cmbValoracion.addItem(i);
        cmbValoracion.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        cmbValoracion.setPreferredSize(new Dimension(260, 34));
        gbc.gridx = 1;
        root.add(cmbValoracion, gbc);

        /* ===== CAMPO ANOTACIONES ===== */
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblN = new JLabel(texts.getString("update.field.annotation") + ":");
        lblN.setFont(fuenteLabel);
        gbc.anchor = GridBagConstraints.NORTHWEST;
        root.add(lblN, gbc);
        gbc.anchor = GridBagConstraints.CENTER;

        txtAnotaciones = new JTextArea(4, 20);
        txtAnotaciones.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        txtAnotaciones.setLineWrap(true);
        txtAnotaciones.setWrapStyleWord(true);
        JScrollPane scrollAnotaciones = new JScrollPane(txtAnotaciones);
        scrollAnotaciones.setPreferredSize(new Dimension(260, 90));
        gbc.gridx = 1;
        root.add(scrollAnotaciones, gbc);

        /* ===== FAVORITO ===== */
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;

        JPanel panelFav = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panelFav.setOpaque(false);

        btnFavorito = new JToggleButton();
        btnFavorito.setIcon(cargarIconoEscalado("/img/estrellagris.png", 42, 42));
        btnFavorito.setSelectedIcon(cargarIconoEscalado("/img/estrellaamarilla.png", 42, 42));
        btnFavorito.setBorderPainted(false);
        btnFavorito.setContentAreaFilled(false);
        btnFavorito.setFocusPainted(false);
        btnFavorito.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel lblFav = new JLabel(texts.getString("update.favorite"));
        lblFav.setFont(new Font("Arial", Font.BOLD, 14));

        panelFav.add(btnFavorito);
        panelFav.add(lblFav);
        root.add(panelFav, gbc);

        /* ===== PANEL INFERIOR ===== */
        JPanel panelInferior = new JPanel(new BorderLayout());
        panelInferior.setBorder(BorderFactory.createEmptyBorder(5, 25, 18, 25));
        panelInferior.setOpaque(false);

        btnCancelar = crearBotonMorado(
                texts.getString("update.cancel"),
                new Dimension(120, 32),
                e -> dispose()
        );

        btnAceptar = crearBotonMorado(
                texts.getString("update.accept"),
                new Dimension(200, 38),
                e -> validarYActualizar()
        );

        getRootPane().setDefaultButton(btnAceptar);

        panelInferior.add(btnCancelar, BorderLayout.WEST);
        panelInferior.add(btnAceptar, BorderLayout.EAST);

        add(panelInferior, BorderLayout.SOUTH);

        SwingUtilities.invokeLater(() -> requestFocusInWindow());
    }

    /**
     * Carga las plataformas desde la base de datos y las añade al desplegable.
     */
    private void cargarPlataformas() {
        try {
            PlataformaDAO plataformaDAO = new PlataformaDAO_imp();
            List<Plataforma> plataformas = plataformaDAO.fetchAll();
            for (Plataforma p : plataformas) {
                cmbPlataforma.addItem(p);
            }
        } catch (Exception e) {
            System.err.println("Error al cargar plataformas: " + e.getMessage());
        }
    }

    /**
     * Crea un campo de texto con el estilo visual común de la aplicación.
     *
     * @return campo de texto configurado
     */
    private JTextField crearCampoTexto() {
        JTextField campo = new JTextField();
        campo.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        campo.setPreferredSize(new Dimension(260, 34));
        return campo;
    }

    /**
     * Activa un comportamiento de placeholder editable en un campo de texto.
     *
     * @param campo        campo de texto
     * @param valorInicial valor inicial que actúa como placeholder
     */
    private void activarPlaceholderEditable(JTextField campo, String valorInicial) {
        campo.setText(valorInicial);
        campo.setForeground(Color.BLACK);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(valorInicial)) campo.setText("");
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().trim().isEmpty()) campo.setText(valorInicial);
            }
        });
    }

    /**
     * Carga los datos actuales del videojuego en el formulario.
     * <p>
     * Para la plataforma, busca en el desplegable el item cuyo nombre
     * coincida con la plataforma guardada en el videojuego y lo selecciona.
     * Si no coincide ninguno, deja el primero seleccionado.
     * </p>
     */
    private void cargarDatos() {
        activarPlaceholderEditable(txtTitulo, videojuego.getTitulo());

        // Seleccionar la plataforma correcta en el desplegable
        String plataformaActual = videojuego.getPlataforma();
        for (int i = 0; i < cmbPlataforma.getItemCount(); i++) {
            if (cmbPlataforma.getItemAt(i).getNombre().equals(plataformaActual)) {
                cmbPlataforma.setSelectedIndex(i);
                break;
            }
        }

        String anioStr = videojuego.getAnio() != null
                ? String.valueOf(videojuego.getAnio()) : "";
        activarPlaceholderEditable(txtAnio, anioStr);

        if (videojuego.getValoracion() != null) {
            cmbValoracion.setSelectedItem(videojuego.getValoracion().intValue());
        }

        txtAnotaciones.setText(
                videojuego.getAnotacion() != null ? videojuego.getAnotacion() : ""
        );

        btnFavorito.setSelected(videojuego.isFavorito());
    }

    /**
     * Crea un botón con estilo morado personalizado.
     *
     * @param texto  texto del botón
     * @param tamaño tamaño del botón
     * @param action acción a ejecutar al pulsar
     * @return botón configurado
     */
    private JButton crearBotonMorado(
            String texto,
            Dimension tamaño,
            ActionListener action
    ) {
        JButton boton = new JButton(texto) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(180, 120, 255),
                        0, getHeight(), new Color(110, 40, 180)
                );
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.dispose();
                super.paintComponent(g);
            }
        };

        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setContentAreaFilled(false);
        boton.setOpaque(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setPreferredSize(tamaño);
        boton.addActionListener(action);
        return boton;
    }

    /**
     * Valida los datos introducidos y actualiza el videojuego.
     * <p>
     * El favorito se gestiona directamente sobre el campo booleano
     * {@code favorito} de la entidad, sin tabla separada.
     * La plataforma se obtiene del objeto {@code Plataforma} seleccionado.
     * </p>
     */
    private void validarYActualizar() {

        if (txtTitulo.getText().trim().isEmpty()
                || txtAnio.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    texts.getString("update.error.empty")
            );
            return;
        }

        int opcion = JOptionPane.showConfirmDialog(
                this,
                texts.getString("update.confirm"),
                texts.getString("update.confirm.title"),
                JOptionPane.YES_NO_OPTION
        );

        if (opcion != JOptionPane.YES_OPTION) return;

        try {
            videojuego.setTitulo(txtTitulo.getText().trim());

            Plataforma plataformaSeleccionada = (Plataforma) cmbPlataforma.getSelectedItem();
            if (plataformaSeleccionada != null) {
                videojuego.setPlataforma(plataformaSeleccionada.getNombre());
            }

            try {
                String input = txtAnio.getText().trim();
                if (input.contains("/")) {
                    java.time.LocalDate d = java.time.LocalDate.parse(input,
                            java.time.format.DateTimeFormatter.ofPattern("d/M/yyyy"));
                    videojuego.setAnio(d.getYear());
                } else {
                    videojuego.setAnio(Integer.parseInt(input));
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, texts.getString("insert.error.year"));
                return;
            }

            videojuego.setValoracion(new BigDecimal((Integer) cmbValoracion.getSelectedItem()));
            videojuego.setAnotacion(txtAnotaciones.getText().trim());
            videojuego.setFavorito(btnFavorito.isSelected());

            videojuegoDAO.update(videojuego);

            JOptionPane.showMessageDialog(
                    this,
                    texts.getString("update.success"),
                    texts.getString("update.success.title"),
                    JOptionPane.INFORMATION_MESSAGE
            );

            dispose();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    texts.getString("update.error.generic"),
                    texts.getString("update.error.title"),
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    /**
     * Carga y escala un icono desde los recursos del proyecto.
     *
     * @param ruta  ruta del icono
     * @param ancho ancho deseado
     * @param alto  alto deseado
     * @return icono escalado
     */
    private ImageIcon cargarIconoEscalado(String ruta, int ancho, int alto) {
        ImageIcon icono = new ImageIcon(getClass().getResource(ruta));
        Image img = icono.getImage().getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }
}