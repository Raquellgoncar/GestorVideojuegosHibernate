/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Controlador.ListadoVideojuegosController;
import Modelo.Videojuego;
import Modelo.Usuario;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Vista de listado de videojuegos del usuario.
 * <p>
 * Muestra en tarjetas todos los videojuegos asociados al usuario
 * autenticado, junto con información básica como plataforma, año,
 * valoración y anotaciones. Los favoritos se destacan con una estrella dorada.
 * </p>
 *
 * Sigue el patrón MVC, delegando la obtención de datos y la navegación
 * en {@link ListadoVideojuegosController}.
 *
 * @author Raquel
 * @version 2.0
 */
public class ListadoVideojuegosVista extends JFrame {

    /** Usuario autenticado */
    private Usuario usuario;

    /** Panel que contiene las tarjetas de videojuegos */
    private JPanel panelTarjetas;

    /** Imagen de fondo de la vista */
    private Image imagenFondo;

    /** Recursos de internacionalización */
    private ResourceBundle texts;

    /** Etiqueta que muestra el total de videojuegos */
    private JLabel lblTotal;

    /** Controlador asociado a la vista */
    private ListadoVideojuegosController controller;

    /**
     * Constructor de la vista de listado de videojuegos.
     *
     * @param usuario usuario autenticado
     */
    public ListadoVideojuegosVista(Usuario usuario) {
        this.usuario = usuario;

        texts = ResourceBundle.getBundle("i18n.messages");

        controller = new ListadoVideojuegosController(usuario);
        controller.setVista(this);

        setTitle(texts.getString("list.window.title"));
        setSize(700, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setExtendedState(MenuPrincipalVista.estadoVentana);
        addWindowStateListener(e -> MenuPrincipalVista.estadoVentana = getExtendedState());

        var url = getClass().getResource("/img/fondoListado.jpg");
        if (url != null) {
            imagenFondo = new ImageIcon(url).getImage();
        }

        initComponents();
        cargarVideojuegos();
    }

    /**
     * Inicializa y organiza los componentes gráficos de la ventana.
     */
    private void initComponents() {

        JPanel root = new JPanel(new BorderLayout(0, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (imagenFondo != null) {
                    g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        setContentPane(root);

        /* ===== TÍTULO ===== */
        JLabel lblTitulo = new JLabel(
                texts.getString("list.title"),
                SwingConstants.CENTER
        );
        lblTitulo.setFont(new Font("Showcard Gothic", Font.PLAIN, 42));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(40, 10, 30, 10));
        root.add(lblTitulo, BorderLayout.NORTH);

        /* ===== PANEL DE TARJETAS ===== */
        panelTarjetas = new JPanel();
        panelTarjetas.setLayout(new BoxLayout(panelTarjetas, BoxLayout.Y_AXIS));
        panelTarjetas.setOpaque(false);
        panelTarjetas.setBorder(BorderFactory.createEmptyBorder(5, 30, 10, 30));

        JScrollPane scroll = new JScrollPane(panelTarjetas);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        root.add(scroll, BorderLayout.CENTER);

        /* ===== PANEL INFERIOR ===== */
        JPanel panelSur = new JPanel(new BorderLayout());
        panelSur.setOpaque(false);
        panelSur.setBorder(BorderFactory.createEmptyBorder(4, 12, 10, 12));

        JButton btnAtras = crearBotonAtras();

        JPanel panelIzq = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelIzq.setOpaque(false);
        panelIzq.add(btnAtras);

        lblTotal = new JLabel();
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTotal.setForeground(Color.WHITE);

        JPanel panelDer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelDer.setOpaque(false);
        panelDer.add(lblTotal);

        panelSur.add(panelIzq, BorderLayout.WEST);
        panelSur.add(panelDer, BorderLayout.EAST);
        root.add(panelSur, BorderLayout.SOUTH);
    }

    /**
     * Crea una tarjeta visual para un videojuego.
     * <p>
     * El título y las anotaciones aparecen a la izquierda/centro.
     * Plataforma, año y valoración aparecen en la fila superior.
     * La estrella dorada solo se muestra si {@code v.isFavorito()} es true.
     * </p>
     *
     * @param v videojuego a mostrar
     * @return panel con la tarjeta del videojuego
     */
    private JPanel crearTarjeta(Videojuego v) {

        JPanel tarjeta = new JPanel(new BorderLayout(10, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 215));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 22, 22);
                g2.dispose();
            }
        };
        tarjeta.setOpaque(false);
        tarjeta.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        /* ===== ESTRELLA (solo si favorito, a la derecha) ===== */
        if (v.isFavorito()) {
            JLabel lblEstrella = new JLabel("★");
            lblEstrella.setFont(new Font("Segoe UI", Font.PLAIN, 32));
            lblEstrella.setForeground(new Color(255, 185, 0));
            lblEstrella.setVerticalAlignment(SwingConstants.CENTER);
            lblEstrella.setHorizontalAlignment(SwingConstants.CENTER);
            lblEstrella.setPreferredSize(new Dimension(48, 48));
            tarjeta.add(lblEstrella, BorderLayout.EAST);
        }

        /* ===== CONTENIDO: fila superior + anotaciones ===== */
        JPanel contenido = new JPanel();
        contenido.setLayout(new BoxLayout(contenido, BoxLayout.Y_AXIS));
        contenido.setOpaque(false);

        /* --- Fila: título | plataforma | año | puntuación --- */
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        fila.setOpaque(false);

        Font fuenteTitulo = new Font("Segoe UI Black", Font.PLAIN, 22);
        Font fuenteDato   = new Font("Segoe UI", Font.BOLD, 20);
        Color colorTitulo = new Color(40, 20, 80);
        Color colorDato   = new Color(80, 50, 130);
        Color colorSep    = new Color(160, 140, 190);

        fila.add(label(v.getTitulo(), fuenteTitulo, colorTitulo));

        fila.add(separador(colorSep));
        fila.add(label(v.getPlataforma(), fuenteDato, colorDato));

        if (v.getAnio() != null) {
            fila.add(separador(colorSep));
            fila.add(label(String.valueOf(v.getAnio()), fuenteDato, colorDato));
        }

        if (v.getValoracion() != null) {
            fila.add(separador(colorSep));
            fila.add(label(
                    v.getValoracion().toPlainString(),
                    new Font("Segoe UI Black", Font.PLAIN, 22),
                    new Color(110, 40, 180)
            ));
        }

        fila.setAlignmentX(Component.LEFT_ALIGNMENT);
        contenido.add(fila);

        /* --- Anotaciones debajo --- */
        boolean tieneAnotacion = v.getAnotacion() != null && !v.getAnotacion().trim().isEmpty();
        if (tieneAnotacion) {
            contenido.add(Box.createRigidArea(new Dimension(0, 5)));
            JLabel lblAnotacion = new JLabel(
                    "<html><i>" + v.getAnotacion().trim().replace("<", "&lt;") + "</i></html>"
            );
            lblAnotacion.setFont(new Font("Segoe UI", Font.ITALIC, 16));
            lblAnotacion.setForeground(Color.GRAY);
            lblAnotacion.setAlignmentX(Component.LEFT_ALIGNMENT);
            contenido.add(lblAnotacion);
        }

        tarjeta.add(contenido, BorderLayout.CENTER);
        tarjeta.setMaximumSize(new Dimension(Integer.MAX_VALUE, tieneAnotacion ? 130 : 90));

        return tarjeta;
    }

    /**
     * Crea un JLabel simple con fuente y color dados.
     */
    private JLabel label(String texto, Font fuente, Color color) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(fuente);
        lbl.setForeground(color);
        return lbl;
    }

    /**
     * Crea un separador visual entre elementos de la fila.
     */
    private JLabel separador(Color color) {
        JLabel sep = new JLabel("   |   ");
        sep.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        sep.setForeground(color);
        return sep;
    }

    /**
     * Crea el botón para volver al menú principal.
     *
     * @return botón configurado
     */
    private JButton crearBotonAtras() {
        JButton boton = new JButton(texts.getString("common.back")) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(180, 120, 255),
                        0, getHeight(), new Color(110, 40, 180)
                );
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
                g2.dispose();
                super.paintComponent(g);
            }
        };

        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setContentAreaFilled(false);
        boton.setOpaque(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setPreferredSize(new Dimension(120, 30));
        boton.addActionListener(e -> controller.volverMenu());
        return boton;
    }

    /**
     * Carga los videojuegos del usuario como tarjetas y actualiza el contador total.
     * <p>
     * El favorito se lee directamente con {@code v.isFavorito()}, sin necesidad
     * de un Set de IDs separado.
     * </p>
     */
    private void cargarVideojuegos() {
        panelTarjetas.removeAll();

        List<Videojuego> videojuegos = controller.obtenerVideojuegos();
        int total = 0;

        if (videojuegos != null && !videojuegos.isEmpty()) {
            for (Videojuego v : videojuegos) {
                panelTarjetas.add(crearTarjeta(v));
                panelTarjetas.add(Box.createRigidArea(new Dimension(0, 30)));
                total++;
            }
        }

        lblTotal.setText(
                texts.getString("list.total.prefix") +
                " " + usuario.getNombre() + ": " + total
        );

        panelTarjetas.revalidate();
        panelTarjetas.repaint();
    }
}