package Vista;

import Controlador.InsertarVideojuegoController;
import Modelo.DAO.Imp.PlataformaDAO_imp;
import Modelo.DAO.PlataformaDAO;
import Modelo.Plataforma;
import Modelo.Usuario;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.ResourceBundle;

public class InsertarVideojuegoVista extends JFrame {

    private JTextField txtTitulo, txtAnio;
    private JComboBox<Plataforma> cmbPlataforma;
    private JComboBox<String> cmbGenero;
    private JComboBox<Integer> cmbValoracion;
    private JTextArea txtAnotaciones;
    private JToggleButton btnFavorito;
    private JButton btnAceptar, btnCancelar;
    private Usuario usuario;
    private ModificarVideojuegosVista padre;
    private ResourceBundle texts;
    private InsertarVideojuegoController controller;
    private String imagenUrlDesdeAPI = null;

    private static final String[] GENEROS = {
        "",
        "Action", "Adventure", "RPG", "Strategy", "Shooter",
        "Puzzle", "Arcade", "Platformer", "Racing", "Sports",
        "Fighting", "Simulation", "Family", "Board Games",
        "Educational", "Card", "Casual", "Massively Multiplayer",
        "Indie"
    };

    public InsertarVideojuegoVista(Usuario usuario) {
        this(usuario, null);
    }

    public InsertarVideojuegoVista(Usuario usuario, ModificarVideojuegosVista padre) {
        this.usuario = usuario;
        this.padre = padre;
        texts = ResourceBundle.getBundle("i18n.messages");
        controller = new InsertarVideojuegoController(usuario);
        controller.setVista(this);
        setTitle(texts.getString("insert.window.title"));
        setSize(660, 640);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
    }

    public void prerellenarDesdeAPI(String titulo, String plataforma, Integer anio, String genero, String imagenUrl) {
        txtTitulo.setText(titulo);
        txtAnio.setText(anio != null ? String.valueOf(anio) : "");
        this.imagenUrlDesdeAPI = imagenUrl;

        // Seleccionar plataforma
        for (int i = 0; i < cmbPlataforma.getItemCount(); i++) {
            if (cmbPlataforma.getItemAt(i).getNombre().equals(plataforma)) {
                cmbPlataforma.setSelectedIndex(i);
                break;
            }
        }

        // Seleccionar género y deshabilitar (viene de la API, no editable)
        if (genero != null && !genero.isEmpty()) {
            boolean encontrado = false;
            for (int i = 0; i < cmbGenero.getItemCount(); i++) {
                if (cmbGenero.getItemAt(i).equalsIgnoreCase(genero)) {
                    cmbGenero.setSelectedIndex(i);
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) cmbGenero.setSelectedIndex(0);
        }
        cmbGenero.setEnabled(false); // deshabilitado porque viene de la API

        // Campos no editables
        txtTitulo.setEditable(false);
        txtTitulo.setBackground(new Color(240, 235, 255));
        txtAnio.setEditable(false);
        txtAnio.setBackground(new Color(240, 235, 255));
        cmbPlataforma.setEnabled(false);
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        JPanel root = new JPanel(new GridBagLayout());
        root.setBorder(BorderFactory.createEmptyBorder(25, 30, 0, 30));
        add(root, BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(9, 10, 9, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitulo = new JLabel(texts.getString("insert.title"), SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Showcard Gothic", Font.PLAIN, 34));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        root.add(lblTitulo, gbc);
        gbc.gridwidth = 1;

        Font fl = new Font("Arial", Font.BOLD, 15);

        // Título
        gbc.gridy++; gbc.gridx = 0;
        JLabel lT = new JLabel(texts.getString("insert.field.title") + ":"); lT.setFont(fl); root.add(lT, gbc);
        txtTitulo = crearCampo(); gbc.gridx = 1; root.add(txtTitulo, gbc);

        // Plataforma
        gbc.gridy++; gbc.gridx = 0;
        JLabel lP = new JLabel(texts.getString("insert.field.platform") + ":"); lP.setFont(fl); root.add(lP, gbc);
        cmbPlataforma = new JComboBox<>(); cargarPlataformas();
        cmbPlataforma.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        cmbPlataforma.setPreferredSize(new Dimension(340, 34));
        gbc.gridx = 1; root.add(cmbPlataforma, gbc);

        // Año
        gbc.gridy++; gbc.gridx = 0;
        JLabel lA = new JLabel(texts.getString("insert.field.year") + ":"); lA.setFont(fl); root.add(lA, gbc);
        txtAnio = crearCampo(); gbc.gridx = 1; root.add(txtAnio, gbc);

        // Género (desplegable fijo)
        gbc.gridy++; gbc.gridx = 0;
        JLabel lG = new JLabel("Género:"); lG.setFont(fl); root.add(lG, gbc);
        cmbGenero = new JComboBox<>(GENEROS);
        cmbGenero.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        cmbGenero.setPreferredSize(new Dimension(340, 34));
        cmbGenero.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value,
                    int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value == null || value.toString().isEmpty()) {
                    setText("— Sin género —");
                    setForeground(isSelected ? Color.WHITE : Color.GRAY);
                }
                return this;
            }
        });
        gbc.gridx = 1; root.add(cmbGenero, gbc);

        // Valoración
        gbc.gridy++; gbc.gridx = 0;
        JLabel lV = new JLabel(texts.getString("insert.field.rating") + ":"); lV.setFont(fl); root.add(lV, gbc);
        cmbValoracion = new JComboBox<>();
        for (int i = 1; i <= 10; i++) cmbValoracion.addItem(i);
        cmbValoracion.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        cmbValoracion.setPreferredSize(new Dimension(340, 34));
        gbc.gridx = 1; root.add(cmbValoracion, gbc);

        // Anotaciones
        gbc.gridy++; gbc.gridx = 0;
        JLabel lN = new JLabel(texts.getString("insert.field.annotation") + ":"); lN.setFont(fl);
        gbc.anchor = GridBagConstraints.NORTHWEST; root.add(lN, gbc); gbc.anchor = GridBagConstraints.CENTER;
        txtAnotaciones = new JTextArea(3, 20);
        txtAnotaciones.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        txtAnotaciones.setLineWrap(true); txtAnotaciones.setWrapStyleWord(true);
        JScrollPane sc = new JScrollPane(txtAnotaciones);
        sc.setPreferredSize(new Dimension(340, 100));
        gbc.gridx = 1; root.add(sc, gbc);

        // Favorito
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 2;
        JPanel pf = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0)); pf.setOpaque(false);
        btnFavorito = new JToggleButton();
        btnFavorito.setIcon(cargarIcono("/img/estrellagris.png", 42, 42));
        btnFavorito.setSelectedIcon(cargarIcono("/img/estrellaamarilla.png", 42, 42));
        btnFavorito.setBorderPainted(false); btnFavorito.setContentAreaFilled(false);
        btnFavorito.setFocusPainted(false); btnFavorito.setCursor(new Cursor(Cursor.HAND_CURSOR));
        JLabel lF = new JLabel(texts.getString("insert.favorite")); lF.setFont(new Font("Arial", Font.BOLD, 14));
        pf.add(btnFavorito); pf.add(lF); root.add(pf, gbc);

        // Botones
        JPanel pi = new JPanel(new BorderLayout());
        pi.setBorder(BorderFactory.createEmptyBorder(5, 25, 18, 25)); pi.setOpaque(false);
        btnCancelar = boton(texts.getString("insert.cancel"), new Dimension(120, 32), e -> volverAtras());
        btnAceptar = boton(texts.getString("insert.accept"), new Dimension(200, 38), e -> validarYProcesar());
        getRootPane().setDefaultButton(btnAceptar);
        pi.add(btnCancelar, BorderLayout.WEST); pi.add(btnAceptar, BorderLayout.EAST);
        add(pi, BorderLayout.SOUTH);
    }

    private void volverAtras() {
        if (padre != null) {
            dispose();
            padre.setVisible(true);
            new SeleccionarModoInsertarDialog(padre, usuario).setVisible(true);
        } else {
            controller.volverModificar();
        }
    }

    private void cargarPlataformas() {
        try {
            PlataformaDAO dao = new PlataformaDAO_imp();
            for (Plataforma p : dao.fetchAll()) cmbPlataforma.addItem(p);
        } catch (Exception e) { System.err.println("Error plataformas: " + e.getMessage()); }
    }

    private JTextField crearCampo() {
        JTextField c = new JTextField();
        c.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        c.setPreferredSize(new Dimension(340, 34));
        return c;
    }

    private JButton boton(String texto, Dimension tam, ActionListener a) {
        JButton b = new JButton(texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, new Color(180, 120, 255), 0, getHeight(), new Color(110, 40, 180)));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.dispose(); super.paintComponent(g);
            }
        };
        b.setForeground(Color.WHITE); b.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
        b.setFocusPainted(false); b.setBorderPainted(false); b.setContentAreaFilled(false);
        b.setOpaque(false); b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(tam); b.addActionListener(a); return b;
    }

    private void validarYProcesar() {
        if (txtTitulo.getText().trim().isEmpty() || txtAnio.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, texts.getString("insert.error.empty"),
                    texts.getString("insert.error.empty.title"), JOptionPane.WARNING_MESSAGE);
            return;
        }
        Integer anio;
        try {
            String input = txtAnio.getText().trim();
            if (input.contains("/")) {
                java.time.LocalDate d = java.time.LocalDate.parse(input,
                        java.time.format.DateTimeFormatter.ofPattern("d/M/yyyy"));
                anio = d.getYear();
            } else {
                anio = Integer.parseInt(input);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, texts.getString("insert.error.year")); return;
        }

        Plataforma p = (Plataforma) cmbPlataforma.getSelectedItem();
        String plat = p != null ? p.getNombre() : "";
        BigDecimal val = new BigDecimal((Integer) cmbValoracion.getSelectedItem());
        String anot = txtAnotaciones.getText().trim();
        String gen = (String) cmbGenero.getSelectedItem();
        if (gen == null) gen = "";

        try {
            if (imagenUrlDesdeAPI != null || !gen.isEmpty()) {
                controller.insertarVideojuegoDesdeAPI(
                        txtTitulo.getText().trim(), plat, anio, val, anot,
                        btnFavorito.isSelected(), gen, imagenUrlDesdeAPI);
            } else {
                controller.insertarVideojuego(
                        txtTitulo.getText().trim(), plat, anio, val, anot,
                        btnFavorito.isSelected());
            }
            JOptionPane.showMessageDialog(this,
                    texts.getString("insert.success") +
                    (btnFavorito.isSelected() ? " " + texts.getString("insert.success.favorite") : ""),
                    texts.getString("insert.success.title"), JOptionPane.INFORMATION_MESSAGE);
            controller.volverModificar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, texts.getString("insert.error.generic"),
                    texts.getString("insert.error.title"), JOptionPane.ERROR_MESSAGE);
        }
    }

    private ImageIcon cargarIcono(String ruta, int w, int h) {
        ImageIcon i = new ImageIcon(getClass().getResource(ruta));
        return new ImageIcon(i.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH));
    }
}
